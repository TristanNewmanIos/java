/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factorialsboxes;

import javax.swing.JOptionPane;

/**
 *
 * @author Tristan
 */
public class FactorialsBoxes {

    /**
     * @param args the command line arguments
     */
        public static void main(String[] args) {
        
        String numberString=
                JOptionPane.showInputDialog("Enter whole number.");
        
        int wholeNumber= Integer.parseInt(numberString);
        int factorial= wholeNumber;
        wholeNumber-= 1;
        
        for(int i=wholeNumber;i>0;i--){
            
            
            factorial*= wholeNumber;
            wholeNumber-= 1;
        
        }
        
        JOptionPane.showMessageDialog(null, factorial);
        System.exit(0);
    }
    
}
