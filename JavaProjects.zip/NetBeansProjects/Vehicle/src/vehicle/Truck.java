/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

/**
 *
 * @author Tristan
 */
public class Truck extends Vehicle{
    
    double loadCapacity;
    double towingCapacity;
    
    public Truck(){
        
        super();
        loadCapacity= 0.0;
        towingCapacity= 0.0;
    }
    
    void setLoadCapacity(double n){
        
        loadCapacity= n;
    }
    
    void setTowingCapacity(double n){
        
       towingCapacity= n;
    }
    
    public double getLoadCapacity(){
        
        return loadCapacity;
    }
    
    public double getTowingCapacity(){
        
        return towingCapacity;
    }
    
    void displayTruck(String ownerName, int cN, String manuN, double load, double tow){
        
        System.out.println(ownerName);
        System.out.println("Number of cylinders: "+ cN);
        System.out.println("Manufacturer number: "+ manuN);
        System.out.println("Load capacity(tons): "+ load);
        System.out.println("Towing capacity(tons): "+ tow);
    }
    
}
