/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

/**
 *
 * @author Tristan
 */
public class demo {
    
     public static void main(String[] args) {
        
         Truck t = new Truck();
         t.setOwner("Ricky Bobby");
         t.setLoadCapacity(1.20);
         t.setTowingCapacity(3.02);
         t.setManuNumber("8g9o3b");
         t.setCylinder(12);
         t.displayTruck(t.getOwner(),t.getCylinder(),t.getManuNumber(),t.getLoadCapacity(),t.getTowingCapacity());
         
    }
    
}
