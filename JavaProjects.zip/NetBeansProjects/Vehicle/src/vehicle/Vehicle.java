/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

/**
 *
 * @author Tristan
 */
public class Vehicle {

    private String manufacturerNumber;
    private int cylinderCount;
    
    private Person owner = new Person();
    
    public void setManuNumber(String n){
        
        manufacturerNumber= n;
    }
    
    public void setCylinder(int n){
        
        cylinderCount= n;
    }
    
    public void setOwner(String ownerName){
        
        owner = new Person(ownerName);
    }
    
    public String getManuNumber(){
        
        return manufacturerNumber;
    }
    
    public String getOwner(){
        return owner.getName();
    }
    
    public int getCylinder(){
        
        return cylinderCount;
    }
   
}
