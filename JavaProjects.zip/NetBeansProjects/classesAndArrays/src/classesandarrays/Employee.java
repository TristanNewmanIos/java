package classesandarrays;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Scanner;
import java.util.Arrays;

public class Employee {

    //int originalArray [] = new int [10];
    private int Eno;
    private String Ename;
    private double Hours [] = new double [7];
    private double Salary [] = new double [7];
    private double Rate;
    private double Gross_Salary;
    
    //Assigns 0s and blanks to variables
    
    void Employee(){
        
        Eno=0;
        String Ename=" ";
        double [] Hours= {0,0,0,0,0,0,0};
        double [] Salary= {0,0,0,0,0,0,0};
        double Rate=0;
        double Gross_Salary=0;
    }
    
    void Input(){
        
        Scanner input=new Scanner(System.in);
        /*System.out.println("Enter employee's number.");
        Eno= input.nextInt();
        
       System.out.println("Enter employee's name.");
       Ename= input.next();*/
       for(int i=1; i<=7;i++){

           System.out.println("How many hours did "+Ename+" work on day "+i+" of the week.(0-24)"); 
           Hours[(i-1)]= input.nextDouble();
           
           while(Hours[(i-1)]<0||Hours[(i-1)]>24){
               System.out.println("Invalid entry.(0-24)"); 
               Hours[(i-1)]= input.nextDouble();
           }
        }
        
        
        System.out.println("Enter employee's hourly pay."); 
        Rate= input.nextDouble();
           
    }
    
    void Display(){
        
        System.out.println("Employee's number is: " + Eno);
        
        System.out.println("Employee's first name is: " + Ename);
        
        System.out.println("Employee's pay rate is: " + Rate+ " per hour.");
        
        System.out.println("Employee worked: " + Arrays.toString(Hours)+ "(by day of the week)");
        
        System.out.println("Employee was paid: " + Arrays.toString(Salary)+"(by day of the week)");
        
        System.out.println("Enter employee's gross salary is: " + Gross_Salary);
        
    }
    
    
    void Calculate(){
        
        
        
        //Calculates salary
        for(int i=0; i<7;i++){
           
           Salary[i]= Hours[i]*Rate;
           
           //Calculates pay for weekend time
           if(i==0||i==6){
                   Salary[i]*= 2;
                   
            }
           
           //Calculates overtime
           else if(Hours[i]>8){
                Salary[i]+= (Hours[i]-8)*Rate*.5;
                    
                //Calculates double over
                if(Hours[i]>12){
                    Salary[i]+= (Hours[i]-12)*Rate*.5;
                }
            }  
            
           //Calclates gross salary
           Gross_Salary+=Salary[i];
        }
    }  
}
