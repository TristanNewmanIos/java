/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classesandarrays;

public class ClassesAndArrays {

    
    public static void main(String[] args) {
        
        Employee e1= new Employee();
        e1.Employee();
        e1.Input();
        e1.Calculate();
        e1.Display();
        
    }
    
}
