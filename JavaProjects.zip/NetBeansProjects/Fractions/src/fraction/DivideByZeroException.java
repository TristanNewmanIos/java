/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fraction;

/**
 *
 * @author Tristan
 */
public class DivideByZeroException extends Exception
{
   public DivideByZeroException()
   {
       super("Cannot divide by zero!");
   }
   public DivideByZeroException(String message)
   {
       super(message);
   }

}

