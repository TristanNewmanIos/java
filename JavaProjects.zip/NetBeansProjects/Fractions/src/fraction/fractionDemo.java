/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fraction;
import java.util.Scanner;
/**
 *
 * @author Tristan
 */
public class fractionDemo {
    
     public static void main(String[] args) {
       Scanner input = new Scanner(System.in);

       try {
           System.out.println("Enter numerator of first fraction: ");
           int numer1 = input.nextInt();
           System.out.println("Enter denominator of first fraction: ");
           // Ask for denominator and handle 0
           // User will have 3 tries to enter a non-zero denominator
           // After 3 tries, program ends.
           int counter = 1;
           int denom1 = input.nextInt();
           while (denom1 == 0 && counter <= 3) {
               System.out.println("Cannot divide by zero!\nPlease enter a non-zero denominator.");
               denom1 = input.nextInt();
               counter++;
           }
           if (denom1 == 0)
               throw new DivideByZeroException();

           String answer = input.next();
           
            System.out.println("Enter numerator of second fraction: ");
            int numer2 = input.nextInt();
           // Ask for denominator and handle 0
           // User will have 3 tries to enter a non-zero denominator
           // After 3 tries, program ends.
            System.out.println("Enter deonminator of second fraction: ");
            int denom2 = input.nextInt();
            counter = 1;
            while (denom2 == 0 && counter <= 3) {
               System.out.println("Cannot divide by zero!\nPlease enter a non-zero denominator.");
               denom2 = input.nextInt();
               counter++;
            }
            if (denom2 == 0)
               throw new DivideByZeroException();

           Fraction f1 = new Fraction(numer1, denom1);
            System.out.println("Your first fraction in simplest form: " + f1.toString() + "\tReciprocal: " + f1.reciprocalToString());
            Fraction f2 = new Fraction(numer2, denom2);
            System.out.println("Your second fraction in simplest form: " + f2.toString() + "\tReciprocal: " + f2.reciprocalToString());
            f1.compare(f1, f2);



           Fraction f3 = f1.add(f2);
           System.out.println("Addition: " + f1 + " + " + f2 + " = " + f3);
           f3 = f1.subtract(f2);
           System.out.println("Subtraction: " + f1 + " - " + f2 + " = " + f3);
           f3 = f1.divide(f2);
           System.out.println("Division " + f1 + " / " + f2 + " = " + f3);
           f3 = f1.multiply(f2);
           System.out.println("Multiplication " + f1 + " x " + f2 + " =  " + f3);
       }
       catch (DivideByZeroException e)
       {
           System.out.println(e.getMessage());
       }
    }
      
}
