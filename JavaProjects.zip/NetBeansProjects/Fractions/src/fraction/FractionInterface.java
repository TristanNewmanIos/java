/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fraction;

/**
 *
 * @author Tristan
 */
interface FractionInterface {
    
     int getNumerator();
   void setNumerator(int numerator);
   int getDenominator();
   void setDenominator(int denominator);

   /** Calculate Greatest Common Denominator
    * @param numerator fraction's numerator
    * @param denominator fraction's denominator
    * @return the greatest common denominator of the numerator and denominator
    * */
   int calculateGCD(int numerator, int denominator);

   /** Adds two fractions
    * @param fractionTwo takes the second fraction and adds it to the first
    * @return the resulting fraction from the addition of first fraction and second fraction
    * */
   Fraction add(Fraction fractionTwo);

   /** Subtracts two fractions
    * @param fractionTwo the second fraction, subtracts it to the first
    * @return the resulting fraction from the subtraction of first fraction and second fraction
    * */
   Fraction subtract(Fraction fractionTwo);

   /** Multiplies two functions
    * @param fractionTwo the second fraction, multiplies it to the first
    * @return the resulting fraction from the multiplication of first fraction and second fraction
    * */
   Fraction multiply(Fraction fractionTwo);

   /** Divides two fractions
    * @param fractionTwo the second fraction, divides it to the first
    * @return the resulting fraction from the division of first fraction and second fraction
    * */
   Fraction divide(Fraction fractionTwo);

   /** @return result as string */
   @Override
   String toString();

   /** Prints a message comparing which fraction is greater, less than, or equal to the other
    * @param fractionOne first fraction
    * @param fractionTwo  second fraction
    * */
   void compare(Fraction fractionOne, Fraction fractionTwo);
    
}
