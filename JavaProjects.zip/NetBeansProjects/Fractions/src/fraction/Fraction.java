
package fraction;

import java.util.Scanner;


//"tk" is to come for correcting errors
public class Fraction {

   int numerator;
   int denominator;

   /** Constructor */
   public Fraction(int numr, int denr) {
       numerator = numr;
       denominator = denr;
       reduce();
   }

   public int getNumerator() {
       return numerator;
   }

   public void setNumerator(int numerator) {
       numerator = numerator;
   }

   public int getDenominator() {
       return denominator;
   }

   public void setDenominator(int denominator) {
       denominator = denominator;
   }

   /** Calculate Greatest Common Denominator */
   public int calculateGCD(int numerator, int denominator) {
       if (numerator % denominator == 0) {
           return denominator;
       }
       return calculateGCD(denominator, numerator % denominator);
   }

   /** Reduce the fraction to lowest form */
   void reduce() {
       int gcd = calculateGCD(numerator, denominator);
       numerator /= gcd;
       denominator /= gcd;
   }

   /** Adds two fractions */
   public Fraction add(Fraction fractionTwo) {
       int newNumerator = (numerator * fractionTwo.getDenominator()) +
               (fractionTwo.getNumerator() * denominator);
       int newDenominator = denominator * fractionTwo.getDenominator();
       return new Fraction(newNumerator, newDenominator);
   }

   /** Subtracts two fractions */
   public Fraction subtract(Fraction fractionTwo) {
       int newNumerator = (numerator * fractionTwo.denominator) -
               (fractionTwo.numerator * denominator);
       int newDenominator = denominator * fractionTwo.denominator;
       Fraction result = new Fraction(newNumerator, newDenominator);
       return result;
   }

   /** Multiplies two functions */
   public Fraction multiply(Fraction fractionTwo) {
       int newNumerator = numerator * fractionTwo.numerator;
       int newDenominator = denominator * fractionTwo.denominator;
       Fraction result = new Fraction(newNumerator, newDenominator);
       return result;
   }

   /** Divides two fractions */
   public Fraction divide(Fraction fractionTwo) {
       int newNumerator = numerator * fractionTwo.getDenominator();
       int newDenominator = denominator * fractionTwo.numerator;
       Fraction result = new Fraction(newNumerator, newDenominator);
       return result;
   }

   /** Returns result as string */
   @Override
   public String toString() {
       return numerator + "/" + denominator;
   }
   
   /** Compares two fractions*/
   /** Returns a message comparing which fraction is greater, less than, or equal to the other */
   public void compare(Fraction fractionOne, Fraction fractionTwo) {
       if ((double)fractionOne.numerator / fractionOne.denominator > (double)fractionTwo.numerator / fractionTwo.denominator)
           System.out.println(fractionOne.toString() + " is greater than " + fractionTwo.toString());
       else if ((double)fractionOne.numerator / fractionOne.denominator < (double)fractionTwo.numerator / fractionTwo.denominator)
           System.out.println(fractionOne.toString() + " is less than " + fractionTwo.toString());
       else
           System.out.println(fractionOne.toString() + " and " + fractionTwo.toString() + " are equal!");
   }

   
   /** Returns the fractions's reciprocal as a string */
    public String reciprocalToString() {
        return denominator + "/" + numerator;
    }


}   

