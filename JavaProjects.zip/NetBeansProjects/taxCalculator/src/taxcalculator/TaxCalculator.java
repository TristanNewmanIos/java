/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taxcalculator;

import javax.swing.JOptionPane;

/**
 *
 * @author Tristan
 */
public class TaxCalculator {

    public static void main(String[] args) {
        
        String incomeString=
                JOptionPane.showInputDialog("Enter whole number income.");
        
        int incomeNumber= Integer.parseInt(incomeString);
        
        double taxDue;        
        if(incomeNumber<= 9325){
            
            taxDue= incomeNumber*.1;
        }
        
        else if(incomeNumber>= 9326 && incomeNumber<= 37950){
            
            taxDue= incomeNumber*.15;
        }
        
        else if(incomeNumber>= 37951 && incomeNumber<= 91900){
            
            taxDue= incomeNumber*.25;
        }
        
        else if(incomeNumber>= 91901 && incomeNumber<= 191650){
            
            taxDue= incomeNumber*.28;
        }
        
        else if(incomeNumber>= 191651 && incomeNumber<= 416700){
            
            taxDue= incomeNumber*.33;
        }
        
        else if(incomeNumber>= 416701 && incomeNumber<= 418400){
            
            taxDue= incomeNumber*.35;
        }
        
        else{
            
            taxDue= incomeNumber*.396;
        }
        
        JOptionPane.showMessageDialog(null,"Your taxes are "+taxDue);
        
        System.exit(0);
    }
    
}
