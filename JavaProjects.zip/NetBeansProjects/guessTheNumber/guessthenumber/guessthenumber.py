import random

print ("This is a number guessing program.")
targetNum = random.randint(1,100)
diff=1

#This while loop, prompts the user to enter a number and then compares it to the
#program generated number, tells them higher or lower, until they guess the number.

#input(quotes): Takes input from the user in the data type they provide
    
#if diff==0:
    #print "You got it!"
    
while diff!=0:
    guessNum = input("Type your guess form 1 to 100: ")
    diff = guessNum-targetNum
    
    if diff>0:
        print "Guess lower"
        
    if diff<0:
     print "Guess higher"
     
print("You guessed it.")