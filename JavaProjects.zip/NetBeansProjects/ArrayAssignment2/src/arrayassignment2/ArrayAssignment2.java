/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayassignment2;

import java.util.Scanner;

public class ArrayAssignment2 {

    
    public static void main(String[] args) {
       
        Scanner input = new Scanner(System.in); 
        
        int [] array = new int [10];
        int even = 0, odd = 0;
        
        System.out.println("Please enter your 10 ten numbers:\n");
        
        for(int i= 0; i < 10; i++){
        
            array [i]= input.nextInt();
        
        if (array[i]%2>0){
            odd+= array[i];
        }
               
        else{
                
            even+= array[i];
                };

        
        
        }
        System.out.println("Odd sum is: " + odd + " Even sum is: " + even);
    }
    
}
