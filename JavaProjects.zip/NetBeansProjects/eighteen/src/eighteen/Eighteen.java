/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eighteen;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Group;
import javafx.scene.canvas.Canvas;
import javafx.scene.shape.ArcType;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javax.swing.JOptionPane;

public class Eighteen extends Application{

    public static void main(String[] args) {
        
        launch(args);
    }
    
    @Override
    public void start(Stage primaryStage) throws Exception{
        
        boolean adult= false;
        
        int answer= 
                JOptionPane.showConfirmDialog(null, "Over 18 years old", "Click Yes or No", 
                        JOptionPane.YES_NO_OPTION);
        
        if(answer==JOptionPane.YES_OPTION){
            
            adult= true;
            System.out.println("You're an adult.");
        }
        else{
            System.out.println("You aren't an adult.");
        }

}
    
}
