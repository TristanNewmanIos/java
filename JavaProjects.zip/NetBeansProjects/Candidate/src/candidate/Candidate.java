/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 
 */
package candidate;
import java.util.Scanner;

public class Candidate {

    private int Cno;
    private String Cname;
    private int Score;
    
    void Enter(){
        
       Scanner input = new Scanner(System.in);
       System.out.println("Enter the candidates name.");
       Cname = input.next();
       
       System.out.println("Enter the candidates number.");
       Cno = input.nextInt();
       
       System.out.println("Enter the candidates score.");
       Score = input.nextInt();
    }
    
    void Display(){
        
        System.out.println("Candidates number is " + Cno);
        System.out.println("Candidates name is " + Cname);
        System.out.println("Candidates score is " + Score);
    }
    
    void CheckScore(){
        
        if (Score>90){
            
            System.out.println("Excellent");
        }
        else if(Score>80){
        
            System.out.println("Good");
        }
        else{
                System.out.println("Average");
        }    
    }

    
}
