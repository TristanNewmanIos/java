/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package candidate;

public class CandidateDemo {
 
    public static void main(String[] args) {
        
        Candidate C1= new Candidate();
        
        C1.Enter();
        C1.Display();
        C1.CheckScore();
        
}

}
