/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nameboxes;

import javax.swing.JOptionPane;

/**
 *
 * @author Tristan
 */
public class NameBoxes {

    public static void main(String[] args) {
        
        String firstName=
                JOptionPane.showInputDialog("Enter your first name.");
        
        String middleName=
                JOptionPane.showInputDialog("Enter your middle name.");
        
        String lastName=
                JOptionPane.showInputDialog("Enter your last name.");
        
        JOptionPane.showMessageDialog(null, firstName + " "+middleName+" " + lastName);
        System.exit(0);
        
    }
    
}
