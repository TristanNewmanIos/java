
package project1no11atog;
import java.util.Scanner;

public class Project1no11aTog {

    
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        //Problems b and c
        /*System.out.println("Enter number for Armstrong testing.");
        int armNum= input.nextInt();
        int sum=0, remainder, nEternal=armNum;
        
        while(armNum>0){
            
            remainder= armNum%10;
            sum+= remainder*remainder*remainder;
            armNum/= 10;
        }
        if(sum==nEternal){
            System.out.print("Armstrong number.");
        }
        else{
         System.out.println("Not an Armstrong number.") ;  
        }
        
        System.out.println("Enter number for reversing.");
        int revNum = input.nextInt();
        
        System.out.println("Reversal number is ");
        while(revNum>0){
            
            remainder = revNum%10;
            System.out.print(remainder);
            revNum/=10;
        }
        
        //Problems d and e
        
        System.out.println("Enter 1st number for HCF.");
        int hcfNum1 = input.nextInt();
        System.out.println("Enter 2nd number for HCF.");
        int hcfNum2 = input.nextInt();
        
        int hcf=1;
        
        for(int i=1;i<=hcfNum1&&i<=hcfNum2;i++ ){
        
            if((hcfNum1%i)==0&&(hcfNum2%i==0)){
                hcf=i;
            }
        }
        System.out.println("HCF is "+ hcf);
        
        System.out.println("Enter 1st number for LCF.");
        int lcfNum1 = input.nextInt();
        System.out.println("Enter 2nd number for LCF.");
        int lcfNum2 = input.nextInt();
        
        int lcf=1;
        boolean found= false;
        
        for(int i=2;i<=lcfNum1&&i<=lcfNum2&&!found;i++ ){
        
            if((lcfNum1%i)==0&&(lcfNum2%i==0)){
                lcf=i;
                found=true;
            }
        }
        System.out.println("LCF is "+ lcf);
        
        //Problem f and g
        int nEvenSum=0, nOddSum=0;
        System.out.println("Enter integer.");
        int n = input.nextInt();
        
        for(int i=1;i<n;i++){
            
            if(i%2==0){
                
                nEvenSum+= i;
            }
            else{
                nOddSum+= i;
            }
            
        }
        
        System.out.println("Sum of all even numbers up to n is "+nEvenSum);
        System.out.println("Sum of all odd numbers up to n is "+nOddSum);
        
        
        //Problem 12
        
        System.out.println("Enter integer to add fibonacci to.");
        int numA=0, numB=1,sumInter=0, sum=0, fibSetNum = input.nextInt();
        
        for(int i=0;i<fibSetNum;i++){
            
            sumInter=numA+numB;
            numA=numB;
            numB=sumInter;
            sum+=sumInter;
        }
            
        
        
        System.out.println("Sum of fibonacci to your iteration is "+sum);
        
        //Problem 13
        
        System.out.println("Enter number to be raised to a power.");
        int xBase = input.nextInt();
        System.out.println("Enter power to raise it to.");
        int n= input.nextInt();
        int xSum=0, xPower=xBase;
        
        System.out.print("Sum of these powers of "+ xBase+ " is ");
        if(n==0){
            xSum=1;
        }
        
        for(int i=0; i<n;i++){
            
            xSum+=xPower;
            xPower*= xBase;
        }
        
        System.out.println(xSum);*/
                
        // Problem 14
        
        System.out.println("Enter an integer to display integer sequence for.");
        int nRows = input.nextInt();
        int rowNumbers=1, revRowNumbers=nRows, depleter=1;
        
        for (int i=1; i<=nRows;i++){
            
            System.out.println(rowNumbers);
            rowNumbers*= 10;
            rowNumbers+=(i+1);
            revRowNumbers*=10;
            revRowNumbers+=(nRows-i);
            depleter*=10;
        }
        
        System.out.println(" ");
        System.out.println(" ");
        System.out.println(" ");
        
        revRowNumbers= revRowNumbers/10;
        depleter/=10;
        
        while (depleter>0){
            
           System.out.println(revRowNumbers);
           revRowNumbers= revRowNumbers%depleter;
           depleter/=10;
        }
    }
}
    

