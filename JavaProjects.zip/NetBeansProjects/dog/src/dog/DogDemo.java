/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dog;

/**
 *
 * @author Tristan
 */
public class DogDemo {
    
        public static void main(String[] args) {
            
            Dog balto = new Dog();
            balto.age = 8;
            balto.name = "Balto";
            balto.breed = "Siberian Husky";
            balto.writeOutput();
            
            Dog scooby = new Dog();
            scooby.age = 41;
            scooby.name = "Scooby";
            scooby.breed = "Great Dane";
            
            System.out.println(scooby.name + " is a " + scooby.breed + ".");
            System.out.println("He is " + scooby.age + " years old, or");
            int humanYears = scooby.getAgeInHumanYears();
            System.out.println (humanYears + " in human years.");
        }
        
    }
    

