/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dog;


public class Dog {

    String name;
    int age;
    String breed;
    public void writeOutput()
    {
        System.out.println("Name: " + name);
        System.out.println("Age in calendar years: " + age);
        System.out.println("Age in human years: " + getAgeInHumanYears());
        System.out.println("Breed: " + breed);
        
    }
    
    public int getAgeInHumanYears(){
        
        int humanYears;
        if(age<=2){
            humanYears= age*11;
            
        }
        else{
            humanYears= 22 + ((age-2) *5);
        }
        
        return humanYears;
    }
    
}
