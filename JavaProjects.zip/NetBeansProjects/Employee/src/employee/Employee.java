/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;

/**
 *
 * @author Tristan
 */
public class Employee extends Person{

    private double salary = 90000.00;
    private int hireDate = 1990;
    private String idNumber = "1324";
    
    //constructor
    public Employee(){
        
        super();
        salary = 0.00;
        hireDate = 0;
        idNumber = " ";
    }
    
    public Employee(String intialName){
        
        String employeeName= intialName;
    }
    
    public void DispalyEmployee(String employeeName, String idN, double sal, int hired){
        
        System.out.println(employeeName);
        System.out.println("ID: "+idN);
        System.out.println("Annual pay:"+sal);
        System.out.println("Year hired: "+hired);
        
    }
    
    //mutator methods
    public void setIDNumber(String n){
        
        idNumber = n;
        
    }
    
    public void setSalary(double n){
        
        salary = n;
        
    }
    
    public void setHired(int n){
        
        hireDate = n;
        
    }
    
    //accessor methods
    public String getNumber(){
        
        return idNumber;
    }
    
    public double getSalary(){
        
        return salary;
    }
    
    public int getHireDate(){
        
        return hireDate;
    }
}
