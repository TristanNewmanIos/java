/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;

public class EmployeeTest {
    
    public static void main(String[] args) {
        
        Employee e = new Employee();
        
        e.setName("Roberto Gonzalez");
        e.setIDNumber("A8Z955061");
        e.setSalary(100000.00);
        e.setHired(2013);
        e.DispalyEmployee(e.getName(), e.getNumber(), e.getSalary(), e.getHireDate());
    }
}
