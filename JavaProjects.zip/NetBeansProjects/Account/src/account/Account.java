/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package account;
import java.util.Scanner;

public class Account {

    int Acno;
    String Name;
    float Balance;
    
    public Account(int accNum, String accName, int accBalance)
	{
		Acno = accNum;
		Name = accName;
		Balance = accBalance;
	}
    
    void Init(){
       
       Scanner input = new Scanner(System.in);
       System.out.println("Enter the account name.");
       Name = input.next();
       
       System.out.println("Enter the account number.");
       Acno = input.nextInt();
       
       System.out.println("Enter the account balance.");
       Balance = input.nextFloat();
   }
    
    void Show(){
       System.out.println("Account number: "+Acno);
       System.out.println("Account name: "+Name);
       System.out.println("Balance: "+Balance);
   }
    
    void Deposit(int Amt){
       Balance+= Amt;
   }
    
    void Withdraw(int Amt){
        if(Amt<=Balance){;
       Balance-= Amt;
            
             if(Balance<500){
                 Balance+=Amt;
                 System.out.println("Insufficient funds.");
             }
        }
   }
    
    float RBalance(){
       return Balance;
   }
    
}
