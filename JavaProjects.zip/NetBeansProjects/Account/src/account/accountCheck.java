/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package account;
import java.util.Scanner;
/**
 *
 * @author Tristan
 */
public class accountCheck {
    
    static Scanner input = new Scanner(System.in);
    static Account[] accountList;
    static int listSize;
    static int acc_Number;
    static String acc_Name;
    static int acc_Balance;
    
    //public void Register(){
            
        //System.out.println("Enter the number of accounts.");
        //listSize = input.nextInt();
        
        
        //}
    
    public static void Transact(int selAcno, int listSize, float balance){
        
        System.out.println("Enter 1 for deposit or 2 for withdraw.");
        int choice= input.nextInt();
        
        
        for(int i=0;i<listSize;i++){
            
            if(accountList[i].Acno==selAcno){
   
                switch(choice){
         
                    case 1:
            
                     System.out.println("Enter amount you wish to deposit.");
                        int Amt = input.nextInt();
                        accountList[i].Deposit(Amt);
                        break;
                
                    case 2:
                
                        System.out.println("Enter amount you wish to withdraw.");
                        System.out.println();
                        Amt = input.nextInt();
                        accountList[i].Withdraw(Amt);
                        break;
                }
            }
        }
    }
    
    static public void Register()
{
	Scanner input = new Scanner(System.in);
        
	accountList = new Account[listSize];
	int counter = 0;
	while (counter < listSize){
		System.out.println("Enter account number, account name, and an account balance >= 500");
		acc_Number = input.nextInt();
		acc_Name = input.next();
		acc_Balance = input.nextInt();
		while (acc_Balance < 500)
		{
			System.out.println("Account balance must be >= 500\nEnter account balance: ");
			acc_Balance = input.nextInt();
		}
		accountList[counter] = new Account(acc_Number, acc_Name, acc_Balance);
		counter++;
        }
}
    
    public static void DisplayAll()
	{
            for (int i = 0; i < accountList.length; i++)
                {
                    accountList[i].Show();
                }
        }
    
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter number of accounts.");
        listSize = input.nextInt();
        Register();
        System.out.println("Enter account number.");
        int selAcno = input.nextInt();
        int n=0;
        
       
        
        for(int i=0;i<listSize;i++){
            
            if(selAcno==accountList[i].Acno){
                n=i;
            }
        }
        
   
        Transact(selAcno, listSize, accountList[n].RBalance());
        DisplayAll();
        
    }
    
}
