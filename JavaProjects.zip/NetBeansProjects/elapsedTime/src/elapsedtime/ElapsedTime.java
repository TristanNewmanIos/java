/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elapsedtime;

import javax.swing.JOptionPane;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class ElapsedTime {

    
    public static void main(String[] args) {
        
        //Collects start time from user
        String startString= JOptionPane.showInputDialog("Input start time in 'HH:MM:SS AM' format.");
        
        //Collects end time from user
        String endString= JOptionPane.showInputDialog("Input end time in 'HH:MM:SS AM' format.");
        
        //Converts start time into time segments (hours, minutes, etc)
        String startHoursString = startString.substring(0,2);
        String startMinutesString = startString.substring(3,5);
        String startSecondsString = startString.substring(6,8);
        String startNoonString = startString.substring(9,11);
        
        //Converts end time into time segments (hours, minutes, etc)
        String endHoursString = startString.substring(0,2);
        String endMinutesString = startString.substring(3,5);
        String endSecondsString = startString.substring(6,8);
        String endNoonString = startString.substring(9,11);
        
        //Converts start time into int data types
        int startHoursInt= Integer.parseInt(startHoursString);
        int startMinutesInt= Integer.parseInt(startMinutesString);
        int startSecondsInt= Integer.parseInt(startSecondsString);
        
        //Converts end time into int data types
        int endHoursInt= Integer.parseInt(startHoursString);
        int endMinutesInt= Integer.parseInt(startMinutesString);
        int endSecondsInt= Integer.parseInt(startSecondsString);
        
        //Converts to military time
        if(startHoursInt==12 && startNoonString.contentEquals("AM")){
            startHoursInt=0;
        }
        
        if(startNoonString.contentEquals("PM")){
            startHoursInt+=12;
        }
        
        if(endNoonString.contentEquals("PM")&& endHoursInt!=12){
            endHoursInt+=12;
        }
        
        System.out.println(endHoursInt);
         System.out.println(startHoursInt);
        
        //Calculates elapsed time
        int elapsedMinutes = ((endHoursInt-startHoursInt)*60) +endMinutesInt- startMinutesInt;
        int elapsedSeconds = endSecondsInt-startSecondsInt;
        
        //Displays elapsed time
        JOptionPane.showMessageDialog(null,"Elapsed time: "+elapsedMinutes+" minutes and "+elapsedSeconds+" seconds");
        
    }
    
}
