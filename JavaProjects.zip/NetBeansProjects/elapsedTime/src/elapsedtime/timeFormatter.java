/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elapsedtime;
import java.text.DateFormat;

public class timeFormatter {
    
}
