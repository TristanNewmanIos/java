/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package olympicsign;

import javafx.application.Application;
import javafx.scene.canvas.Canvas;
import javafx.scene.Scene;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.shape.ArcType;
import javafx.stage.Stage;
import javafx.scene.Group;

/**
 *
 * @author Tristan
 */
public class OlympicSign extends Application {
    
    public static void main(String[] args) {
        launch(args);
    }
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        
        Group root= new Group();
        Scene scene= new Scene(root);
        Canvas canvas= new Canvas(400,500);
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.strokeOval(10, 10, 10, 10);
    }

    
    
    
}
