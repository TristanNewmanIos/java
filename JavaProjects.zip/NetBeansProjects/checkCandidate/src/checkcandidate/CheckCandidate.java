/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package checkcandidate;

import java.util.Arrays;
import java.util.Scanner;

public class CheckCandidate {
	static Candidate[] candidateList;
	static int listSize;
	static int number;
	static String name;
	static int score;
	

	public static void setArraySize()
	{
		Scanner input = new Scanner(System.in);
		System.out.println("Enter number of candidates to enroll: ");
		listSize = input.nextInt();		
	}
	

	public static void Enroll()
	{
		Scanner input = new Scanner(System.in);
		candidateList = new Candidate[listSize];
		int counter = 0;
		while (counter < listSize)
		{
			System.out.println("Enter number, name, and score of candidate: ");	// asked for values
			number = input.nextInt();	// entered user input values into variables
			name = input.next();
			score = input.nextInt();
			candidateList[counter] = new Candidate(number, name, score);
			counter++;
		}
		

	}
	

	public static void Search()
	{
		Scanner input = new Scanner(System.in);
		int searchScore;
		boolean found = true;
		System.out.println("Enter score to use for search: ");
		searchScore = input.nextInt();
		for (int i = 0; i < listSize; i++)
		{
			if(searchScore == candidateList[i].getCscore())
			{
				candidateList[i].DisplayCandidateInfo();
                                found=false;
                        }
                       
		}	
                if ( found){
                    System.out.println("Could not find score.");
                }
	}
	

	public static void getPass()
	{
		Scanner input = new Scanner(System.in);
		

		System.out.println("\nThese candidates get a pass: ");
		for (int i = 0; i < listSize; i++)
		{
			if (candidateList[i].getCscore() >= 33)
				candidateList[i].DisplayCandidateInfo();
		}
	}
	

	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		

//		System.out.println("Enter number, name, and score of candidate: ");	// asked for values
//		number = input.nextInt();	// entered user input values into variables
//		name = input.next();
//		score = input.nextInt();
//		Candidate C2 = new Candidate(number, name, score);	// created an object
//		C2.DisplayCandidateInfo();
//		
//		Candidate C3 = new Candidate();
//		C3.setCdata();
//		C3.DisplayCandidateInfo();
		

		setArraySize();
		Enroll();
		Search();
		getPass();
	}

}

