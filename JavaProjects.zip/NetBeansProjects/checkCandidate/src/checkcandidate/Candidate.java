/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package checkcandidate;

import java.util.Scanner;

public class Candidate
{
private int Cno;
private String Cname;
private int Cscore;

Scanner input = new Scanner(System.in);

	public Candidate()	// Default constructor
	{
		Cno = 0;
		Cname = "Empty";
		Cscore = 0;
	}
	public Candidate(int num, String name, int score) // Constructor to give programmer the option to input object values themselves
	{
		Cno = num;
		Cname = name;
		Cscore = score;
	}
	public void setCdata() // Take all inputs from user and enter into our instance variables
	{
		System.out.println("Enter number, name, and score of candidate: ");	// asked for values
		Cno = input.nextInt();	// entered user input values into variables
		Cname = input.next();
		Cscore = input.nextInt();
	}
	public void DisplayCandidateInfo()
	{
		System.out.println("\nCandidate Information:");
		System.out.println("Number: " + Cno);
		System.out.println("Name: " + Cname);
		System.out.println("Score: " + Cscore);
                
	}
	public int getCno()
	{
		return Cno;
	}
	public String getCname()
	{
		return Cname;
	}
	public int getCscore()
	{
		return Cscore;
	}
}
