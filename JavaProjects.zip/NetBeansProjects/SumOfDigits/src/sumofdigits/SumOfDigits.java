/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sumofdigits;
import java.util.Scanner;

public class SumOfDigits {

    
    public static void main(String[] args) {
        
        int eSum=0, oddSum=0,eCount=0, oddCount=0, remainder=0;
        Scanner input = new Scanner(System.in);
        System.out.println("Enter number to be assessed.");
        int n= input.nextInt();
        
        while(n>0){
        
            remainder=n%10;
            n/=10;
            
            if(remainder%2>0){
                
                oddSum+= remainder;
                oddCount++;
            }
            else{
                eSum+= remainder;
                eCount++;
            }
            
            
        }
        
        System.out.println("Sum of even numbers is "+eSum);
         System.out.println("Sum of odd numbers is "+oddSum);
          System.out.println("Count of even numbers is "+eCount);
           System.out.println("Count of odd numbers is "+oddCount);
    }
    
}
