
package candidate1;
import java.util.Scanner;

public class Candidate1 {


    private int Cno;
    private String Cname;
    private int Score;
    Candidate1[] enrol;
    Scanner input = new Scanner(System.in);
    
    void Enter(){
        
           
        System.out.println("Enter the candidates name.");
        Cname = input.next();
       
        System.out.println("Enter the candidates number.");
        Cno = input.nextInt();
       
         System.out.println("Enter the candidates score.");
         Score = input.nextInt();
 
    }
    
    void Display(){
        
        System.out.println("Candidates number is " + Cno);
        System.out.println("Candidates name is " + Cname);
        System.out.println("Candidates score is " + Score);
    }
    
    void Enrol(int n,Candidate1[] enrol){
        
        //Call the constructor function individually
        enrol[n];
        
        for(int i=0;i<n;i++){
           
            enrol[i].Enter();
        }
    }
   
    void Search(int n){
        
        System.out.println("Enter Score to search for.");
        int searchScore = input.nextInt();
        
        for(int i=0; i<n;i++){
            
            if (searchScore== enrol[i].Score){
                enrol[i].Display();
            }
            else{
                System.out.println("Fail to find.");
            }
        }
        
    }
}
