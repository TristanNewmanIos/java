/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package candidate1;
import java.util.Scanner;

public class candidate1Demo {
     public static void main(String[] args) {
         
         
         Scanner input= new Scanner(System.in);
         System.out.println("Enter number of candidates.");
         int n = input.nextInt();
         Candidate1[] c1= new Candidate1[n];
         Enrol(c1);
         Search(n);
     }
}
