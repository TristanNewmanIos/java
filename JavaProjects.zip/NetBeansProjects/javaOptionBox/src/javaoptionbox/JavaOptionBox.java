/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaoptionbox;

import javax.swing.JOptionPane;

public class JavaOptionBox {
    
    public static void main(String[] args) {
        //launch(args);

        boolean adult= false;
        
        int answer= JOptionPane.showConfirmDialog(null,"Are you over 18?","Click yes or no",
                JOptionPane.YES_NO_OPTION);
        if (answer==JOptionPane.YES_OPTION){
            adult= true;
            System.out.println("You're an adult.");
        }
    }
   
}
