/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package booleanprime;

import java.util.Scanner;

/**
 *
 * @author Tristan
 */
public class BooleanPrime {

    boolean BooleanPrime(int num){
            
            boolean flag=true;
        
            for(int i=2;(i<=num-1)&&(flag);i++){
            
                if((num%i)==0)
                //checks if divisible by any number other than 1 and itself
            
                flag=false;
                //If switched to false, than number is composite
            }
         
         return flag;
         
    }
        
}
