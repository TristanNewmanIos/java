/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package booleanprime;
import java.util.Scanner;
/**
 *
 * @author Tristan
 */
public class BooleanPrimeArray {
    
    public static void main(String[] args){
        
       int array[]= new int [10];
       int prime[]= new int [10];
       int count = 0;
       Scanner input = new Scanner(System.in);
       
       for(int i = 0;i<10;i++){
           
        System.out.println("Enter whole number for prime array.");
        array [i] = input.nextInt();
        
        BooleanPrime tester = new BooleanPrime();
        if(tester.BooleanPrime(array[i])){
            prime[i]= array[i];
            ++count;
        }
        
       }
       System.out.println("You entered " + count + " prime numbers.");
       System.out.println("The prime numbers you entered are ");
       
       for(int i = 0; i<10; i++){
          
           if (prime[i]>0){
            System.out.println(prime[i]);
           }
       }
    }
}
