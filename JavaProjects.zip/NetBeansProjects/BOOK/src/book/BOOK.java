/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package book;
import java.util.Scanner;
/**
 *
 * @author Tristan
 */
public class BOOK {

    private int Bno;
    private String Bname;
    private String Author;
    private float Price;
    
    void Enter(){
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter the book number.");
        Bno = input.nextInt();
        
        System.out.println("Enter the book's name.");
        Bname = input.next();
        
        System.out.println("Enter the author's name.");
        Author = input.next();
        
        System.out.println("Enter the book price.");
        Price = input.nextFloat();
        
    }
    
    void Display(){
        System.out.println("Book number: " + Bno);
        System.out.println("Book name: " + Bname);
        System.out.println("Author's name is " +Author);
        System.out.println("Price is "+Price);
    }
    
    int RBno(){
        return Bno;
    }
    
    String RBname(){
        return Bname;
    }
    
}
