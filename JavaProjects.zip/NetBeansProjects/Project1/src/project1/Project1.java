/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;
import java.util.Scanner;
/**
 *
 * @author Tristan
 */
public class Project1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
        
        double num;
        Scanner input=new Scanner(System.in);
        
        System.out.println("Enter a number");
   
        num=input.nextDouble();
        
        if( num >100){ 
            
            System.out.println("Big number");
        }
    }
    
}
