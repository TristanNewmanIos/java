import random

while True:
    
    print("This is a dice rolling program.")
    print("Press enter to roll.")
    raw_input("Press Enter to continue...")
    
    number=random.randint(1,6)
    print(number)