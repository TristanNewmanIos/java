/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adding2;
import java.util.Scanner;
/**
 *
 * @author Tristan
 */
public class Adding2 {

    public static void main(String[] args) {
        
        Scanner input=new Scanner(System.in);
        
        int n, sum=1;
        
        n = input.nextInt();
        System.out.println("enter n.");
        
        for(int i = 0; n<=i;i++){
            
            sum+=
            System.out.println(sum+(n*2));
           
        }
        
    }
    
}
