/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pkg2darrayassignment;
import java.util.Scanner;
import java.util.Arrays;

/**
 *
 * @author Tristan
 */
public class Array2DTest{
    
    public static void main(String[] args) {

      //Question 3.4
      Array2D a = new Array2D();
      a.CREATE(3);
      a.Display();
      a.SWAP(a.matrix);
      a.Display();
     // a.SWAP(a.m3x3);
      //1
     // a.Display(a.swapMatrix);
      
    }
}
       /* Question 1:
          0 1 2 3 
          0 1 2 3 
          0 1 2 3 
        
        int[ ][ ] testArray = new int[3][4];
        for (int row = 0; row < testArray.length; row++)
        for (int col = 0; col < testArray[row].length; col++)
            testArray[row][col] = col;
        for (int row = 0; row < testArray.length; row++)
            
        {
         for (int col = 0; col < testArray[row].length; col++)
             System.out.print(testArray[row][col] + " ");
             System.out.println();
}*/
       
        /*Question 2:
        Scanner input= new Scanner(System.in);
        int [][] a = new int[4][5];
        int sumDiagStartTopLeft, sumDiagStartTopRight;
        
        
        for(int i=0;i<a.length;i++){
            
            for(int j=0;j<a[0].length;j++){
                
                System.out.println("Enter integer for row " + i+ " column: "+j);
                a[i][j]= input.nextInt();
            }
        }*/
        
        /*Question 3.1. Displays contents of the array in matrix form
        int [][] a= new int [1][1];
        int [][] b= new int [1][1];
        int allSum=0, evenSum=0, oddSum=0;
        
        //Takes the inputs of the array
        
        for(int i=0;i<a.length;i++){
            
            for(int j=0;j<a[0].length;j++){
                
                System.out.println("Enter integer for row " + i+ " column: "+j);
                a[i][j]= input.nextInt();
            }
            
        }
        
        for (int row = 0; row < a.length; row++)
            
        {
         for (int col = 0; col < a[row].length; col++)
             System.out.print(a[row][col] + " ");
             System.out.println();
        }
        System.out.println(a[0][0]);
        
        //Finds the sum of all, odd, and even elements in the array
        for(int i=0;i<a.length;i++){
            
            for(int j=0;j<a[0].length;j++){
                
                allSum+= a[i][j];
                
                if (a[i][j]%2>0){
                    evenSum +=a[i][j];
                }
                else{
                    oddSum +=a[i][j];
                }
            }
        }
        
        System.out.println("Sum of all, even, and odds elements are: "+allSum+", "+evenSum+", "+oddSum+".");*/
        
        /*Question 3.2 Takes the input of 2 2d arrays adds, subtracts and displays them
        
        int [][] a= new int [2][2];
        int [][] b= new int [2][2];
        int [][] sums= new int [2][2];
        int [][] diffs= new int [2][2];
        
        for(int i=0;i<a.length;i++){
            
            for(int j=0;j<a[0].length;j++){
                
                System.out.println("Enter a array integer for row " + i+ " column: "+j);
                a[i][j]= input.nextInt();
            }
            
        }
        
        for(int i=0;i<b.length;i++){
            
            for(int j=0;j<b[0].length;j++){
                
                System.out.println("Enter b array integer for row " + i+ " column: "+j);
                b[i][j]= input.nextInt();
            }
            
        }
        
        //Populates sums array
        for(int i=0;i<b.length;i++){
            
            for(int j=0;j<a[0].length;j++){
                
                sums[i][j]= a[i][j] + b[i][j];
            }
            
        }
        
        //Populates differences array
        
        for(int i=0;i<b.length;i++){
            
            for(int j=0;j<a[0].length;j++){
                
                diffs[i][j]= a[i][j] - b[i][j];
            }
            
        }
        
        //Displays matrixes
        System.out.println("Sums matrix");
        for (int row = 0; row < sums.length; row++)
            
        {
         for (int col = 0; col < sums[row].length; col++)
             System.out.print(sums[row][col] + " ");
             System.out.println();
        }
        
        System.out.println("Difference matrix");
        for (int row = 0; row < diffs.length; row++)
            
        {
         for (int col = 0; col < diffs[row].length; col++)
             System.out.print(diffs[row][col] + " ");
             System.out.println();
        }*/
        
        /*Question 3.3 
        Scanner input= new Scanner(System.in);
        System.out.println("Enter number of rows.");
        int r= input.nextInt();
        
        System.out.println("Enter number of columns.");
        int c= input.nextInt();
        
        int [][] array= new int [r][c];
        int [] rowSums= new int[r];
        int [] colSums= new int[c];
        int topRightDiagSum= 0, topLeftDiagSum= 0;
        
        for(int i=0;i<r;i++){
            
            for(int j=0;j<c;j++){
                
                System.out.println("Enter a array integer for row " + i+ " column: "+j);
                array[i][j]= input.nextInt();
                
                //Finds the sum of the rows
                rowSums[i]+= array[i][j];
                
                //Find the sum of the columns
                colSums[j]+=array[i][j];
                
                //Checks for a square array 
                if(r==c&&i==j){
                    
                    //Cell on diagonal from top left
                    if(i==j){
                    topLeftDiagSum+=array[i][j];
                    }
                    
                    //Checks for square array and cell on diagonal from top right
                    if(i+j==r){
                
                    topLeftDiagSum+=rowSums[i];
                
                }
                
                }
                
                
                
            }
            
        }
        
        System.out.println("Sum of all rows are "+ Arrays.toString(rowSums));
        System.out.println("Sum of all columns are "+ Arrays.toString(colSums));
        if(r==c){
                
            System.out.println("Sum of diagonal from top left is "+ topLeftDiagSum);
            System.out.println("Sum of diagonal from top left is "+ topRightDiagSum);
        }*/
        
        
