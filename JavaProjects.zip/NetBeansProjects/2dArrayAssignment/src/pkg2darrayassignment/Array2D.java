
package pkg2darrayassignment;
import java.util.Scanner;
import java.util.Arrays;

public class Array2D {
    
    Scanner input= new Scanner(System.in);
    int [][] matrix;
    
    //3.4, creates a 3x3 matrix
    void CREATE (int n){
        
        matrix= new int [n][n];
        
        for(int i=0;i<matrix.length;i++){
            
            for(int j=0;j<matrix[0].length;j++){
                
                System.out.println("Enter integer for row " + i+ " column: "+j);
                matrix[i][j]= input.nextInt();
               
            }
           
        }
           
    }
    //3.4, transposes the matrix
    void SWAP (int matrix [][]){
        int t;
        
            for(int r=0;r<matrix.length;r++){
                
                for(int c=r;c<matrix.length;c++){
                    
                    if(r!=c){
                        t= matrix[r][c];
                        matrix[r][c]= matrix[c][r];
                        matrix[c][r]=t;
                    }
                }
            }
            System.out.println();
    }
        
    
        
    void Display (){
            
        
        for(int i=0;i<matrix.length;i++){
            
            for(int j=0;j<matrix[0].length;j++){
                
                System.out.print(matrix[i][j]);}
               System.out.println();
            
        
            
        }
    }
    
}
