/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayassignment3;
import java.util.Scanner;

public class ArrayAssignment3 {

    boolean BooleanPrime(int num){
            
            boolean flag=false;
                
            System.out.println("Enter number for prime testing.");
            Scanner input=new Scanner(System.in);
            num = input.nextInt();
        
            for(int i=2;(i<=num-1)&&!(flag);i++){
            
                if((num%i)==0)
            
                flag=true;
            }
         if (!(flag)){
            System.out.println("Number is prime.");
            }
            else{
             System.out.println("Number is composite.");
            }
         
         return flag;
         
        }
    
    public static void main(String[] args) {
        
        .BooleanPrime(n);
        
    }  
    
}
