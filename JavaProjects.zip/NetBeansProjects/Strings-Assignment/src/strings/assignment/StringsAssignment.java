

package strings.assignment;
import java.util.Arrays;
import java.util.Scanner;

public class StringsAssignment {

    
    public static void main(String[] args) {
        
        /*String greeting="How do you do";
        System.out.println(greeting+"Seven of Nine.");
        
        String test = "abcdefg";
        System.out.println(test.length());
        System.out.println(test.charAt(1));
        
        String test = "abcdefg";
        System.out.println(test.substring(3));
                
        System.out.println("abc\\ndef");
        
        String test = "Hello John";
        test = test.toUpperCase();
        System.out.println(test);
        
        String s1= "Hello John";
        String s2= "hello john";
        boolean i= s1.equals(s2);
                
        System.out.println(i);
        
        String [] array = {"Another", "and", "Batch", "book"};
        for(int i=0; i<array.length;i++){
            
            if(array[i].startsWith("A")||array[i].startsWith("a"))
            {
                System.out.println(array[i]);
            }
        }
        
        Scanner input = new Scanner(System.in);
        boolean flag=false;
        
        String [] array = {"Another", "and", "Batch", "book"};
        System.out.println(Arrays.toString(array));
        System.out.println("Enter string to search this array for. Program will output its place.");
        String search = input.next();
        search.toUpperCase();
        
        //Answer for D.1.
        for(int i=0;array[i].toUpperCase().equals(search);i++){
            
            System.out.println(i);
            flag=false;
        }
        if(!flag){
            System.out.println("No match found.");
        }*/
        
        String [] array = {"Another", "and", "Batch", "book"};
        String test="another";
        boolean example= array[0].equalsIgnoreCase(test);
        boolean compare= array[0].compareTo(test) < 0;
        System.out.println(example);
        System.out.println(compare + ", the first variable comes before the second in lexicographic sequence.");
    }
    
}
