import javafx.application.Application;
import javafx.scene.canvas.Canvas;
import javafx.scene.Scene;
import javafx.scene.Group;
import javafx.stage.Stage;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.shape.ArcTo;
import javafx.scene.shape.ArcType;

public class Frown extends Application 
{
   public static final int WINDOW_WIDTH = 400;
   public static final int WINDOW_HEIGHT = 300;

   public static final int FACE_DIAMETER = 200;
   public static final int X_FACE = 100;
   public static final int Y_FACE = 50;

   public static final int EYE_WIDTH = 10;
   public static final int EYE_HEIGHT = EYE_WIDTH; // problem #1: 20 -> `EYE_WIDTH` (circle)
   public static final int X_RIGHT_EYE = 155;
   public static final int Y_RIGHT_EYE = 100;
   public static final int X_LEFT_EYE = 230;
   public static final int Y_LEFT_EYE = Y_RIGHT_EYE;

   public static final int MOUTH_WIDTH = 100;
   public static final int MOUTH_HEIGHT = 50;
   public static final int X_MOUTH = 150;
   public static final int Y_MOUTH = 160;
   public static final int MOUTH_START_ANGLE = 0;		// problem #2: 180 degrees -> 0 degrees (frowning face)
   public static final int MOUTH_DEGREES_SHOWN = 180;

   public static void main(String[] args)
   {
      launch(args);
   }

   @Override
   public void start(Stage primaryStage) throws Exception
   {
	  Group root = new Group();
   	  Scene scene = new Scene(root);
      Canvas canvas = new Canvas(WINDOW_WIDTH, WINDOW_HEIGHT);
      GraphicsContext gc = canvas.getGraphicsContext2D();
      
      // Draw face outline
      gc.strokeOval(X_FACE, Y_FACE, FACE_DIAMETER, FACE_DIAMETER);
      
      // Draw eyes
	  gc.fillOval(X_RIGHT_EYE, Y_RIGHT_EYE, EYE_WIDTH, EYE_HEIGHT);
	  gc.fillOval(X_LEFT_EYE, Y_LEFT_EYE, EYE_WIDTH, EYE_HEIGHT);
	  
	  // Draw mouth
	  gc.strokeArc(X_MOUTH, Y_MOUTH, MOUTH_WIDTH, MOUTH_HEIGHT,
	               MOUTH_START_ANGLE, MOUTH_DEGREES_SHOWN, ArcType.OPEN);

      root.getChildren().add(canvas);
      primaryStage.setTitle("frown in JavaFX");
      primaryStage.setScene(scene);
      primaryStage.show();
   }
}