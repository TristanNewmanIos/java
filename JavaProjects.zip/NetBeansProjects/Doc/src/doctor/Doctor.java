/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package doctor;

/**
 *
 * @author Tristan
 */
public class Doctor extends Person{
    
    private String doctorName;
    private double visitFee;
    private String doctorType;

    public Doctor(){
        
        super();
        doctorType= " ";
        doctorName= " ";
        visitFee= 0.0;
    }
    
    public void setFee(double fee){
        
        visitFee = fee;
        
    }
    
    public void setSpecialty(String specialty)
    {
        
        doctorType= specialty;
    }    
    public double getFee(){
        
        return visitFee;
    }
    
    public String getSpecialty(){
        
        return doctorType;
    }
    
    public void displayDoctor(String type, String name, double fee){
        
        System.out.println("Name: "+type);
        System.out.println("Name: "+name);
        System.out.println("Cost per visit: "+ fee);
    }
    
}
