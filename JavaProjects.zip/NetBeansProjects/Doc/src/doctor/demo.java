/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package doctor;

/**
 *
 * @author Tristan
 */
public class demo {
    
    public static void main(String[] args) {
        
        Doctor d = new Doctor();
        d.setName("Dr. Dre");
        d.displayDoctor(d.getSpecialty(), d.getName(),d.getFee());
    }
}
