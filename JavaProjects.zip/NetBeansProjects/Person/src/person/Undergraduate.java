/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package person;

/**
 *
 * @author Tristan
 */
public class Undergraduate extends Student{
    
    public void writeOutput(){
        
        System.out.println(super.getName());
        System.out.println(super.getStudentNumber());
    }
    
    public void reset(){
        
        super.setStudentNumber("0");
        super.setName("Maverick");
        
    }
    
}
