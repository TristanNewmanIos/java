/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package person;

/**
 *
 * @author Tristan
 */
public class TitledPerson extends Person{
    
    private String title;
    
    public TitledPerson(){
        
        super();
        title=" ";
    }
    
    public TitledPerson(String initialTitle, String initialName){
        
        super(initialName);
        title= initialTitle;
        
    }
    
    public void writeOutput(){
        
        System.out.println(title+ " ");
        super.writeOutput();
        
    }
    
    public void reset(){
        
        super.setName(" ");
        title= " ";
    }
    
    boolean equal(String t, String n){
        
        if(title==t&&super.getName()==n){
            return true;
        }
        else{
            return false;
        }
    }
    
    String getTitlethat(){
        
        return title;
    }
    
    public void setTitle(String t){
        title= t;
        
    }
    
}
