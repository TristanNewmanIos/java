/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package person;

/**
 *
 * @author Tristan
 */
public class Student extends TitledPerson{
    
    private String sNo;
    
    public void Student(){
        super.setName("Goose");
        this.Student("0");
    }
    
    public void Student(String num){
        
        sNo=num;
    }
    
    String getStudentNumber(){
        
        return sNo;
    }
    
    public void setStudentNumber(String n){
        
        sNo=n;
    }
}
