/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe;

/**
 *
 * @author Tristan
 */
import java.util.Scanner;
/**
 * 3/7/18 CS 111B
 * @author Roberto Herman
 * Team mate: Tristan Newman
 */
public class testTicTacToe
{

	public static void main(String[] args)
	{
                
		Scanner input = new Scanner(System.in);
		char play;
		TicTacToe game = new TicTacToe();
		

		do
		{
		System.out.println("Welcome to Tic Tac Toe!!!");
		game.Display();
		System.out.println("\tLet's begin!\n");
		 for(game.turn = 1; game.turn < 10; game.turn++)
		    { 
			 if (game.win == false)
			 {
				 game.tellTurn(game.turn);
				 game.Move();
				 game.Display();
				 game.TellWinner();
			 }
		    }
		 if (game.win == false)
		 {
			 System.out.println("It's a draw!");
			 game.win = true;
		 }
		 

		 System.out.println("Would you like to play again? (Y or N)");
		 play = input.next().charAt(0);
		 game.win = false;
		 game.Reset(8);
		}
		while (play == 'Y' || play == 'y');
		if (play == 'N' || play == 'n')
			System.out.println("\n\t-=Game Over=-");
	}
}