
package tictactoe;
import java.util.Scanner;
/**
 * 3/7/18 CS 111B
 * @author Roberto Herman
 * Team mate: Tristan Newman
 */
public class TicTacToe
{
private char[][] board = new char[3][3];
public int turn = 1;
boolean win = false;
Scanner input = new Scanner (System.in);

public TicTacToe()		// constructor to start game with a blank board
{
	for (int row = 0; row < 3; row++)
		for (int col = 0; col < 3; col++)
		{
			board[row][col] = ' ';
		}
}
public void Move()
{
    int moveCol, moveRow;
    

    System.out.println("Enter a row and column to make a move (enter 9 to reset):");
    moveRow = input.nextInt() - 1;	  // gets move for the turn from user
    moveRow = CheckBounds(moveRow);	// makes sure it's an appropriate row value
    

    if (moveRow == 8)	// if user inputs 9, then game resets
    {
    	Reset(moveRow);
    	System.out.println("Enter a row and column to make a move (enter 9 to reset):");
    	moveRow= input.nextInt() - 1;
    	moveRow = CheckBounds(moveRow);
    }
    

    moveCol = input.nextInt() - 1;
    moveCol = CheckBounds(moveCol);
    

   if(turn%2==0)	// player x's move
   {         
	   char X = 'x';
       char O = 'o';
       

       // If there is already an x or o played in that row/column, then user is prompted to enter a value between 1 and 3
       while ( (board[moveRow][moveCol] == X) || (board[moveRow][moveCol] == O) )
       {
    	   System.out.println("Someone played there already!\nSelect a different row and column:");
    	   moveRow = input.nextInt() - 1;
    	   moveRow = CheckBounds(moveRow);
    	   moveCol = input.nextInt() - 1;
    	   moveCol = CheckBounds(moveCol);
       }
            board[moveRow][moveCol]= 'x';
   }
   

    else{	//player o's move
            while ( (board[moveRow][moveCol] == 'x') || (board[moveRow][moveCol] == 'o') )
            {
            	System.out.println("Someone played there already.\nSelect a different row and column:");
            		moveRow = input.nextInt() - 1;
            		moveRow = CheckBounds(moveRow);
            		moveCol = input.nextInt() - 1;
            		moveCol = CheckBounds(moveCol);
            }
            board[moveRow][moveCol]= 'o';
    		}
  

}

public void Reset(int reset)
{
	if (reset == 8)	// when user inputs 9 as a row value, game resets
	{
	for (int row = 0; row < 3; row++)
	    	for (int col = 0; col < 3; col++)
	    	{
	    		board[row][col] = ' ';
	    	}
	}
	turn = 1;	// to reset the number of turns when game is reset
	System.out.println("*RESET*");
	System.out.println("\n-= New Game =-");
	tellTurn(turn);
}

public void tellTurn(int turn)
{
    if(turn%2==0){	//	player x's turn
        System.out.println("Player \"X\",");
    }
    else{	//	player o's turn
        System.out.println("Player \"O\",");
    }
}
public void Display()	// Tic tac toe interface
{
	System.out.println();
	System.out.print(board[0][0] + " | ");
	System.out.print(board[0][1] + " | ");
	System.out.println(board[0][2]);
	System.out.println("-- --- --");
	

	System.out.print(board[1][0] + " | ");
	System.out.print(board[1][1] + " | ");
	System.out.println(board[1][2]);
	System.out.println("-- --- --");
	

	System.out.print(board[2][0] + " | ");
	System.out.print(board[2][1] + " | ");
	System.out.println(board[2][2]);
	System.out.println();
}
public void TellWinner()
{

        for(int i=0;i<3;i++){
            if (!win && board[0][i] == 'x' && board[1][i] == 'x' && board [2][i] == 'x'){	// Full column X wins
		
		System.out.println("X wins!");
		win = true;
            }	
            else if (!win && board[0][i] == 'o' && board[1][i] == 'o' && board [2][i] == 'o'){	// Full column O wins	
		System.out.println("O wins!");
		win = true;
            }
            
            else if (!win && board[i][0] == 'o' && board[i][1] == 'o' && board [i][2] == 'o'){	// Full row O wins
            
		System.out.println("O wins!");
		win = true;
            }
            
            else if (!win && board[i][0] == 'x' && board[i][1] == 'x' && board [i][2] == 'x'){	// Full row X wins
		System.out.println("X wins!");
		win = true;
            }
	
	}
	
	if (!win && board[0][0] == 'x' && board[1][1] == 'x' && board [2][2] == 'x')	// Right diagonal X wins
	{
		System.out.println("X wins!");
		win = true;
	}
	else if (!win && board[0][0] == 'o' && board[1][1] == 'o' && board [2][2] == 'o')	// Right diagonal O wins
	{
		System.out.println("O wins!");
		win = true;
	}
	

	if (!win && board[0][2] == 'x' && board[1][1] == 'x' && board [2][0] == 'x')	// Left diagonal X wins
	{
		System.out.println("X wins!");
		win = true;
	}
	else if (!win && board[0][2] == 'o' && board[1][1] == 'o' && board [2][0] == 'o')	// Left diagonal O wins
	{
		System.out.println("O wins!");
		win = true;
	}		
}
public int CheckBounds(int bounds)	//	make sure row/column values are within the array's boundary
{
	while ((bounds != 0) && (bounds != 1) && (bounds != 2) && (bounds != 8))
    {
	System.out.println("There are only 3 rows and 3 columns in TicTacToe!");
	System.out.println("So you have to enter a number between 1 and 3.");
	System.out.println("Try again:");
	bounds = input.nextInt() - 1;
    }
	return bounds;
}
}