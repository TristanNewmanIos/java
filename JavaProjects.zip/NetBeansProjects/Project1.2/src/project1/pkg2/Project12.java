/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1.pkg2;
import java.util.Scanner;

public class Project12 {

    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the nth term.");
        int n = input.nextInt();
        int multipleSum= 1;
        int powerSum2= 0;
        int powerSum3= 1;
        
        for(int i=1;i<=n;i++){
            
            multipleSum+= 1 + 2*(i-1);
            powerSum2+= (2*i)*(2*i);
            powerSum3+= (3*(i-1))*(3*(i-1))*(3*(i-1));
        }
        
        System.out.println("Sum 1 is "+multipleSum);
        System.out.println("Sum 1 is "+powerSum2);
        System.out.println("Sum 1 is "+powerSum3);
        
    }
    
}
