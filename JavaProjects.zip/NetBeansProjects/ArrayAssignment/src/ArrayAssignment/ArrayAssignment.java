
package project1no11aTog;
 import java.util.Scanner; 

class ArrayAssignment{
   
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in); 
        
        double [] array = new double [10];
        double average= 0;
        
        System.out.println("Please enter your 1fancy ten numbers:\n");
        
        for(int i= 0; i < 10; i++){
        
        array [i]= input.nextDouble();
        average += array[i];
        
        }
        
        average /= 10;
       
        System.out.println(average);

        
    }
}
