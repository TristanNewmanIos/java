/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factorialoption;

import javax.swing.JOptionPane;

public class FactorialOption {

    public static void main(String[] args) {
        
        int factorAnswer= JOptionPane.showConfirmDialog(null,
                "Would you like to find a factorial?","Click yes or no",JOptionPane.YES_NO_OPTION);
        
        if(factorAnswer==JOptionPane.YES_OPTION){
            
            String inputString= JOptionPane.showInputDialog("Enter whole number to be factorialed");
            int inputNumber= Integer.parseInt(inputString);
            int factorial= inputNumber;
            
            for(int i=inputNumber-1;i>0;i--){
            
                factorial*= i;
            }
        
            JOptionPane.showMessageDialog(null, factorial);
        }
        
        System.exit(0);
        
    }
    
}
