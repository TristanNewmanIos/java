/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package snowman;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.scene.canvas.Canvas;
import javafx.scene.Scene;
import javafx.scene.Group;
import javafx.stage.Stage;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcTo;
import javafx.scene.shape.ArcType;

public class Snowman extends Application {
    
   public static final int WINDOW_WIDTH = 400;
   public static final int WINDOW_HEIGHT = 400;

   public static final int HEAD_DIAMETER = 50;//eighth of square canvas
   public static final int HEAD_X = 175;
   public static final int HEAD_Y = 0;
   
   public static final int EYE_DIAMETER = HEAD_DIAMETER/5;
   
   public static final int BODY_DIAMETER = 100;//eighth of square canvas
   public static final int BODYUP_X = 150;
   public static final int BODYUP_Y = 50;
   public static final int BODYDOWN_X = BODYUP_X;
   public static final int BODYDOWN_Y = 150;

   public static void main(String[] args) {
        launch(args);
   }
   
   
   @Override
   public void start(Stage primaryStage) throws Exception
   {
      Group root = new Group();
      Scene scene = new Scene(root);
      Canvas canvas = new Canvas(WINDOW_WIDTH, WINDOW_HEIGHT);
      GraphicsContext gc = canvas.getGraphicsContext2D();
      
      //Draws head
      gc.strokeOval(HEAD_X, HEAD_Y, HEAD_DIAMETER, HEAD_DIAMETER);
      
      //Draws face
      gc.fillOval(HEAD_X+HEAD_DIAMETER/4.0,HEAD_Y + HEAD_DIAMETER/3.0, EYE_DIAMETER, EYE_DIAMETER);
      gc.fillOval(HEAD_X+3*HEAD_DIAMETER/4.0,HEAD_Y + HEAD_DIAMETER/3.0, EYE_DIAMETER, EYE_DIAMETER);
      gc.fillOval(HEAD_X+HEAD_DIAMETER/2.0,HEAD_Y + HEAD_DIAMETER/2.0, EYE_DIAMETER, EYE_DIAMETER);
      
      //Draws buttons
      gc.fillOval(BODYUP_X+BODY_DIAMETER/2.0,BODYUP_Y + BODY_DIAMETER/4.0, EYE_DIAMETER, EYE_DIAMETER);
      gc.fillOval(BODYUP_X+BODY_DIAMETER/2.0,BODYUP_Y + 2.0*BODY_DIAMETER/4.0, EYE_DIAMETER, EYE_DIAMETER);
      gc.fillOval(BODYUP_X+BODY_DIAMETER/2.0,BODYUP_Y + 3.0*BODY_DIAMETER/4.0, EYE_DIAMETER, EYE_DIAMETER);
      
      //Draws body
      gc.strokeOval(BODYUP_X, BODYUP_Y, BODY_DIAMETER, BODY_DIAMETER);
      gc.strokeOval(BODYDOWN_X, BODYDOWN_Y, BODY_DIAMETER, BODY_DIAMETER);
      
      //Draws arms
      gc.strokeArc((BODYUP_X-25.0), (BODYUP_Y +10.0), 100.0, 50.0, 100.0, 100.0, ArcType.OPEN);
      gc.strokeArc((BODYUP_X+45.0), (BODYUP_Y *2 - 34.0), 100.0, 75.0, 100.0, -75.0, ArcType.OPEN);
        
      root.getChildren().add(canvas);
      primaryStage.setTitle("Endpoint and friends");
      primaryStage.setScene(scene);
      primaryStage.show();
    }
}


