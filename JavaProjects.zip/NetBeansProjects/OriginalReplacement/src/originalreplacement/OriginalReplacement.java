package originalreplacement;
import java.util.Scanner;
import java.util.Arrays;

public class OriginalReplacement {

    
    public static void main(String[] args) {
       
        Scanner input = new Scanner(System.in);
        int originalArray [] = new int [10];
        int replacement, original;
        
        for (int i=0;i<10;i++){
            
            System.out.println("Enter a whole number for the original replacement array.");
            originalArray[i] = input.nextInt();
        }
        
        int replacementArray []= originalArray;
        System.out.println("Enter the original, then enter the replacement number.");
        original = input.nextInt();
        replacement = input.nextInt();
         System.out.println("Original array is " + Arrays.toString(originalArray));
        
        for (int i=0;i<10;i++){
            
            if(original==replacementArray[i]){
                replacementArray[i]=replacement;
            }
            
        }
        
        System.out.println("Replacement array is " + Arrays.toString(replacementArray));
    }
    
}
