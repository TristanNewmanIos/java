
package endpointgraphic;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.scene.canvas.Canvas;
import javafx.scene.Scene;
import javafx.scene.Group;
import javafx.stage.Stage;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcTo;
import javafx.scene.shape.ArcType;

public class EndpointGraphic extends Application {
    
   public static final int WINDOW_WIDTH = 400;
   public static final int WINDOW_HEIGHT = 400;

   public static final int MIDDLE_DIAMETER = 50;//eighth of square canvas
   public static final int X_MIDDLE = 175;
   public static final int Y_MIDDLE = 175;
   
   public static final int OUTERMIDDLE_DIAMETER = 100;//quarter of square canvas
   public static final int X_OUTERMIDDLE = 150;
   public static final int Y_OUTERMIDDLE = 150;

   public static final int HEMISPHERE_DIAMETER= 200;//half of square canvas, where only half shows
   
   public static final int HEMISPHERE_MIDDLEUP_X= 100;
   public static final int HEMISPHERE_MIDDLEUP_Y= -50;
   
   public static final int HEMISPHERE_MIDDLEDOWN_X= HEMISPHERE_MIDDLEUP_X;
   public static final int HEMISPHERE_MIDDLEDOWN_Y= 250;
   
   public static final int HEMISPHERE_LEFT_X= -50;
   public static final int HEMISPHERE_LEFT_Y= 100;
   
   public static final int HEMISPHERE_RIGHT_X= 250;
   public static final int HEMISPHERE_RIGHT_Y= HEMISPHERE_LEFT_Y;

   public static void main(String[] args) {
        launch(args);
   }
   
   
   @Override
   public void start(Stage primaryStage) throws Exception
   {
      Group root = new Group();
      Scene scene = new Scene(root);
      Canvas canvas = new Canvas(WINDOW_WIDTH, WINDOW_HEIGHT);
      GraphicsContext gc = canvas.getGraphicsContext2D();
      
      gc.setFill(Color.BLUE);
      gc.fillOval(X_MIDDLE, Y_MIDDLE, MIDDLE_DIAMETER, MIDDLE_DIAMETER);
      gc.setStroke(Color.RED);
      gc.strokeOval(X_OUTERMIDDLE, Y_OUTERMIDDLE, OUTERMIDDLE_DIAMETER, OUTERMIDDLE_DIAMETER);
      gc.setStroke(Color.GREEN);
      gc.strokeOval(HEMISPHERE_MIDDLEUP_X, HEMISPHERE_MIDDLEUP_Y, HEMISPHERE_DIAMETER, HEMISPHERE_DIAMETER);
      gc.strokeOval(HEMISPHERE_MIDDLEDOWN_X, HEMISPHERE_MIDDLEDOWN_Y, HEMISPHERE_DIAMETER, HEMISPHERE_DIAMETER);
      gc.strokeOval(HEMISPHERE_RIGHT_X, HEMISPHERE_RIGHT_Y, HEMISPHERE_DIAMETER, HEMISPHERE_DIAMETER);
      gc.strokeOval(HEMISPHERE_LEFT_X, HEMISPHERE_RIGHT_Y, HEMISPHERE_DIAMETER, HEMISPHERE_DIAMETER);
        
      root.getChildren().add(canvas);
      primaryStage.setTitle("Endpoint and friends");
      primaryStage.setScene(scene);
      primaryStage.show();
    }

   
    
    
}


   
      
      /* Draw face outline
      gc.strokeOval(X_FACE, Y_FACE, FACE_DIAMETER, FACE_DIAMETER);
      
      // Draw eyes
	  gc.fillOval(X_RIGHT_EYE, Y_RIGHT_EYE, EYE_WIDTH, EYE_HEIGHT);
	  gc.fillOval(X_LEFT_EYE, Y_LEFT_EYE, EYE_WIDTH, EYE_HEIGHT);
	  
	  // Draw mouth
	  gc.strokeArc(X_MOUTH, Y_MOUTH, MOUTH_WIDTH, MOUTH_HEIGHT,
	               MOUTH_START_ANGLE, MOUTH_DEGREES_SHOWN, ArcType.OPEN);

      root.getChildren().add(canvas);
      primaryStage.setTitle("frown in JavaFX");
      primaryStage.setScene(scene);
      primaryStage.show();*/