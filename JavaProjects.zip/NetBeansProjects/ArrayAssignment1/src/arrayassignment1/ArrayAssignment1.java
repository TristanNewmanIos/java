/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayassignment1;
import java.util.Scanner;

public class ArrayAssignment1 {

    
    public static void main(String[] args) {
       
        Scanner input = new Scanner(System.in); 
        
        int [] array = new int [10];
        int small = 0, big = 0;
        
        System.out.println("Please enter your 10 ten numbers:\n");
        
        for(int i= 0; i < 10; i++){
        
            array [i]= input.nextInt();
        
        if (array[i]>big){
            big= array[i];
        }
        
        else if(array[i]<small){
      
            small= array[i];
        }
               
        else if(i<1){
                
            small= array[i];
            big= array[i];
                };

        
        
        }
        System.out.println("Highest number is: " + big + " Lowest number is: " + small);
    }
    
}
