# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.
bodyPart1=input("Enter a body part.")
bodyPart.=input("Enter a 2nd body part.")
bodyPart1=input("Enter a body part.")

print "Suddenly, he grabs me tipping me accross his"+bodyPart1+". With one "+adjective+
" movement, he angels his "noun1" so my "bodyPart2" is resting on the "noun2+
"beside him. He throws his right "+bodyPart3+" over both mine and "+sVerb+" his left..."

