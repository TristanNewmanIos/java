/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ageoption;

import javax.swing.JOptionPane;

public class AgeOption {

    public static void main(String[] args) {
        
        int factorAnswer= JOptionPane.showConfirmDialog(null,
                "Are you older than 18?","Click yes or no",JOptionPane.YES_NO_OPTION);
        boolean adult= false;
        
        if(factorAnswer==JOptionPane.YES_OPTION){
            
            adult= true;
            System.out.println("You're an adult.");
        }
        
        else{ System.out.println("You aren't an adult.");}
        
        System.exit(0);
    }
    
}
