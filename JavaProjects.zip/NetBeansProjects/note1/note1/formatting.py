# Write two lines of code below, each assigning a value to a variable
first_string= " {} world"

# Now write a print statement using .format() to print out a sentence and the 
#   values of both of the variables

print(first_string.format("hello"))