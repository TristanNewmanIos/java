/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package methodsassignment;
import java.util.Scanner;
/**
 *
 * @author Tristan
 */
public class MethodsAssignment {
    
    public static int COMPOSITE(int n){
            
            boolean flag=false;
            int call;
        
            for(int i=2;(i<=n-1)&&!(flag);i++){
            
                if((n%i)==0)
            
                    flag=true;
            }
            
            if (!(flag)){
                call= 0;
                //Is prime
            }
            
            else{
                call= 1;
                //Is composite
            }
            
            return call;
        
    }
    
    public static int COUNT(int n){
            
         int count=0;
         
         for(int i=1;n>0;i++){
             
             n= n/10;
             count++;
         }
         
         return count;
        
    }
    
    public static int POWER(int n, int p){
         
         int total=n;
         p--;
         
         if(p==0){
             return 1;
         }
         
         while(p>0){
             
             total*= n;
             p-=1;
         }
         
         return total;
        
    }
    
    public​​ static​​ void​ main( String [ ] args){
        
        int num, power;
        
        System.out.println("Enter number for prime testing, counting, and powering.");
            Scanner input=new Scanner(System.in);
            num = input.nextInt();
            
        System.out.println("Enter a power to raise it to.");
            power = input.nextInt();
            
            System.out.println(COMPOSITE(num) +" 0 if composite.");
            System.out.println(COUNT(num) + " digit");
            System.out.println(POWER(num,power));
    }
    
}
