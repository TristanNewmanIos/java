/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numberinterface;

/**
 *
 * @author Tristan
 */
public class demoNumberInterface implements NumberInterface{
    
    public static void main(String[] args) {
        
        lowNumCompute demo= new lowNumCompute();
        
       while(demo.keepGoing()){
           
           demo.setInput();
           demo.setVariables(demo.input, demo.average);
           demo.keepGoing();
       }
        
    }
}
