/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numberinterface;

import javax.swing.JOptionPane;

/** An interface for numbers that returns the second and first lowest numbers entered by the
 * user and their average*/
//doesn't declare constructors for a class
public interface NumberInterface {
    
    /*Takes the input numbers from the user, sets a lowest, second lowest, and finds the average
    *
    */
    
    void setInput();
    void setVariables();
    boolean keepGoing();
    int lowest=0;
    int secondLowest=0;
    int average=0;
    int count=0;
    int total=0;
    int input=0;
    
    }



