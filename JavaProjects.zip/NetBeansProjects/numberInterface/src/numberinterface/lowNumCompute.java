/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numberinterface;

import javax.swing.JOptionPane;

/**
 *
 * @author Tristan
 */
public class lowNumCompute {
    
    int lowest=0;
    int secondLowest=0;
    int average;
    int count;
    int total;
    int input;
    
    public void setInput(){
        
        String inputString = JOptionPane.showInputDialog("Enter an integer.");
        int input = Integer.parseInt(inputString);
        
    }
    
    void setVariables(int input, int avg){
        
        count+= 1;
        total += input;
        
        average= (total/count);
        
        if (input < lowest){
            
            lowest = input;
        }
        
        else if(input<secondLowest){
            
            secondLowest = input;
        }
        
    }
    
    boolean keepGoing(){
        
        boolean onward = true;
        int answer= JOptionPane.showConfirmDialog(null,"Would you like to enter another number?", 
               "Click yes or no", JOptionPane.YES_NO_OPTION);
        
        if(answer==JOptionPane.NO_OPTION){
            onward=false;
        }
        
        return onward;
        
    }
}